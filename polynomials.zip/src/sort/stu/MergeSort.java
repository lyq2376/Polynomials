package sort.stu;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Perform an out of place merge sort on a native array of integers.
 *
 * merge_sort (not in place):
 *     best=O(nlogn)
 *     worst=O(nlogn)
 * file: MergeSort.java
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public class MergeSort {
    /**
     * Split the array on the left side.
     *
     * @param data the full array of data
     * @return the left half side of the data
     */
    private static ArrayList<Integer> splitLeft(ArrayList<Integer> data) {
        int stop = (data.size()/2);
        ArrayList<Integer> left = new ArrayList<Integer>();
        for (int i = 0; i < stop; ++i){
            left.add(data.get(i));
        }
        return left;
    }

    /**
     * Split the array on the right side.
     *
     * @param data the full array of data
     * @return the right half side of the data
     */
    private static ArrayList<Integer> splitRight(ArrayList<Integer> data) {
        ArrayList<Integer> right = new ArrayList<Integer>();
        for (int start = (data.size()/2); start < data.size(); ++start){
            right.add(data.get(start));
        }
        return right;
    }

    /**
     * Merges two sorted arrays, left and right, into a combined sorted array.
     *
     * @param left  a sorted array
     * @param right a sorted array
     * @return one combined sorted array
     */
    private static ArrayList<Integer> merge(
            ArrayList<Integer> left, ArrayList<Integer> right) {
        ArrayList<Integer> result = new ArrayList<Integer>();
        int left_index = 0;
        int right_index = 0;
        while(left_index < left.size() && right_index < right.size()) {
            if (left.get(left_index) <= right.get(right_index)) {
                result.add(left.get(left_index));
                left_index += 1;
            }
            else {
                result.add(right.get(right_index));
                right_index += 1;
            }
        }
        if(left_index < left.size()){
            for(int i = left_index; i < left.size(); i++){
                result.add(left.get(i));
            }
        }
        else if (right_index < right.size()) {
            for(int i = right_index; i < right.size(); i++){
                result.add(right.get(i));
            }
        }
            return result;
    }

    /**
     * Performs a merge sort and returns a newly sorted array
     *
     * @param data the data to be sorted (a native array)
     * @return a sorted array
     */
    private static ArrayList<Integer> mergeSort(ArrayList<Integer> data) {
        if (data.size() < 2){
            return data;
        }
        else{
            return merge(mergeSort(splitLeft(data)), mergeSort(splitRight(data)));
        }
    }

    /**
     * Test function for mergeSort.
     *
     * @param args command line arguments (unused)
     */
    public static void main(String[] args) {
        int[][] DATA = {
                {},
                {0},
                {0, 1},
                {1, 0},
                {0, 1, 2},
                {0, 2, 1},
                {1, 0, 2},
                {1, 2, 0},
                {2, 0, 1},
                {2, 1, 0},
                {9, 5, 2, 4, 3, 8, 0, 4, 0, 9}
        };

        for (int[] data : DATA) {
            // create two lists of the data
            List<Integer> sortData = Arrays.stream(data)
                                           .boxed()
                                           .collect(Collectors.toList());
            List<Integer> sorted = Arrays.stream(data)
                                         .boxed()
                                         .collect(Collectors.toList());
            // merge sort is not in place and returns a new sorted list
            sortData = mergeSort((ArrayList<Integer>) sortData);
            // use built in sort to compare against
            Collections.sort(sorted);
            // show the results of the comparison
            System.out.print("mergeSort: " + Arrays.stream(data)
                                                   .boxed()
                                                   .collect(Collectors.toList())
                             + " result: " + sortData);
            System.out.println(sortData.equals(sorted) ? " OK" : " FAIL");
        }
    }
}
